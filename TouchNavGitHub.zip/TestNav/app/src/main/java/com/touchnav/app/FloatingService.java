package com.touchnav.app;

import android.app.*;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.core.app.NotificationCompat;

public class FloatingService extends Service {
    private WindowManager wm;
    private View btn;
    private WindowManager.LayoutParams p;
    private int ix, iy;
    private float tx, ty;
    private boolean drag;
    private long lastTap;
    private static final String CH = "tn";

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(1, buildNotif());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        btn = new View(this);
        btn.setBackgroundColor(0x881A1A2E);
        int type = Build.VERSION.SDK_INT >= 26
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        p = new WindowManager.LayoutParams(150, 150, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        p.x = 0; p.y = 300;
        btn.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    drag = false; ix = p.x; iy = p.y; tx = e.getRawX(); ty = e.getRawY();
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (Math.abs(e.getRawX()-tx)>10||Math.abs(e.getRawY()-ty)>10) drag=true;
                    if (drag) { p.x=ix+(int)(e.getRawX()-tx); p.y=iy+(int)(e.getRawY()-ty); wm.updateViewLayout(btn,p); }
                    break;
                case MotionEvent.ACTION_UP:
                    if (!drag) {
                        long now = System.currentTimeMillis();
                        if (now-lastTap<350) { NavService.doRecents(); lastTap=0; }
                        else { lastTap=now; btn.postDelayed(()->{ if(System.currentTimeMillis()-lastTap>=340) NavService.doBack(); },350); }
                    }
                    break;
            }
            return true;
        });
        wm.addView(btn, p);
    }

    @Override public int onStartCommand(Intent i, int f, int s) { return START_STICKY; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (btn != null && wm != null) try { wm.removeView(btn); } catch (Exception e) {}
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "TouchNav", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private Notification buildNotif() {
        return new NotificationCompat.Builder(this, CH)
            .setContentTitle("TouchNav Aktif")
            .setContentText("Yüzen düğme çalışıyor")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true).build();
    }
}
